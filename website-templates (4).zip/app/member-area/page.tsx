import MemberArea from "@/templates/member-area"

export default function MemberAreaPage() {
  return <MemberArea />
}
