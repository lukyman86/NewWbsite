import { NotificationCenter } from "@/components/notification-center"

export default function NotificationsPage() {
  return (
    <div className="container py-6">
      <NotificationCenter />
    </div>
  )
}
